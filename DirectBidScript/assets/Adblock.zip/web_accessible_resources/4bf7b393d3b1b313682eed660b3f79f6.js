(function() {
	window.COMSCORE = {
		purge: function() {
			_comscore = [];
		},
		beacon: function() {
			;
		}
	};
})();
